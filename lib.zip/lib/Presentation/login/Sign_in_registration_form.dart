import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pokedex_ddd/Application/auth_bloc/auth_bloc.dart';
import 'package:pokedex_ddd/Application/login_register_bloc/login_bloc.dart';
import 'package:pokedex_ddd/Domain/auth/enum_validation.dart';
import 'package:pokedex_ddd/Presentation/routes/app_routes.dart';

class SignInRegistrationForm extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  SignInRegistrationForm({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<LoginBloc, LoginState>(
      builder: (context, state) {
        return Form(
            key: _formKey,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Center(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Image.asset("assets/images/Pokedex.png"),
                    TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.email),
                        labelText: "Email",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8)),
                        ),
                      ),
                      autocorrect: false,
                      validator: (value) {
                        RegExp emailReg = RegExp(
                          r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
                        );
                        if (emailReg.hasMatch(value!)) {
                          return null;
                        } else {
                          return "Please enter valid email address";
                        }
                      },
                      onChanged: (value) {
                        context
                            .read<LoginBloc>()
                            .add(LoginEvent.emailChanged(value));
                      },
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    TextFormField(
                      obscureText: true,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.password),
                        labelText: "Password",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8)),
                        ),
                      ),
                      autocorrect: false,
                      validator: (value) {
                        if (value!.length >= 6) {
                          return null;
                        } else {
                          return "Please enter valid password";
                        }
                      },
                      onChanged: (value) {
                        
                        context
                            .read<LoginBloc>()
                            .add(LoginEvent.passwordChanged(value));
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Expanded(
                          child: IgnorePointer(
                            ignoring: state.isSubmitting,
                            child: ElevatedButton(
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    context.read<LoginBloc>().add(
                                        const LoginEvent
                                            .signInWithEmailAndPasswordPressd());
                                  }
                                },
                                child: const Text("Login")),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: IgnorePointer(
                            ignoring: state.isSubmitting,
                            child: ElevatedButton(
                                onPressed: () {
                                  if (state.isSubmitting) {
                                    null;
                                  } else {
                                    if (_formKey.currentState!.validate()) {
                                      context.read<LoginBloc>().add(const LoginEvent
                                          .registerWithEmailAndPasswordPressd());
                                    }
                                  }
                                },
                                child: const Text("Register")),
                          ),
                        ),
                      ],
                    ),
                    if (state.isSubmitting) ...[
                      const SizedBox(
                        height: 10,
                      ),
                      const LinearProgressIndicator(),
                    ],
                  ],
                ),
              ),
            ));
      },
      listener: (context, state) {
        state.authFailureSccess.fold(
            () => null,
            (result) => result.fold(
                    (l) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(l.map(
                            serverError: (_) => "Server Error",
                            emailAlreadyRegister: (_) =>
                                "Email already registered",
                            invalideEmailOrPassword: (_) =>
                                "Invalid Email or Password")))), (r) {
                  if (state.authType == AuthType.register) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text("You are now Registered")));
                    _formKey.currentState!.reset();
                  } else {
                    AutoRouter.of(context)
                        .replaceNamed(const HomeScreenRoute().path);
                  }
                  context
                      .read<AuthBloc>()
                      .add(const AuthEvent.checkauthenticated());
                }));
      },
    );
  }
}
