import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pokedex_ddd/Application/auth_bloc/auth_bloc.dart';
import 'package:pokedex_ddd/injection.dart';
import 'package:provider/provider.dart';

class HomeScreenPage extends StatelessWidget {
  const HomeScreenPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (context) {
            return getIt<AuthBloc>();
          },
        )
      ],
      child: Scaffold(
        appBar: AppBar(
          title: Text("Pokedex"),
          actions: [
            IconButton(
                onPressed: () {
                  context.read<AuthBloc>().add(AuthEvent.logout());
                },
                icon: const Icon(Icons.logout)),
          ],
        ),
        body: Center(child: Text("home")),
      ),
    );
  }
}
