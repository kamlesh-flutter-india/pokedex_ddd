enum AuthType {
  login,
  register,
  idial,
}
