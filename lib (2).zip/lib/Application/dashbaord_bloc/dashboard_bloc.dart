import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:pokedex_ddd/Domain/auth/user.dart';
import 'package:pokedex_ddd/Domain/registration/i_user_repository.dart';
import 'package:pokedex_ddd/Domain/registration/user_failure.dart';

part 'dashboard_event.dart';
part 'dashboard_state.dart';
part 'dashboard_bloc.freezed.dart';

class DashboardBloc extends Bloc<DashboardEvent, DashboardState> {
  DashboardBloc(this._iUserRepository) : super(DashboardState.initial());
  final IUserRepository _iUserRepository;
  @override
  Stream<DashboardState> mapEventToState(DashboardEvent event) async* {
    // yield* event.map(started: (value) async* {
    //   yield state.copyWith(isLoading: true);
    //   Either<UserFailure, User> userOption =
    //       await _iUserRepository.getUserDetails();
    //  yield userOption.map((r) => state.copyWith(isLoading: false,
    //  user: r));
    // });

    yield* event.map(started: (e) async* {
      
      Either<UserFailure, User> userOrfailure;
      yield state.copyWith(isLoading: true);
      userOrfailure = await _iUserRepository.getUserDetails();
      userOrfailure.fold((l) => null, (r) => null)
      yield state.copyWith(
        isLoading: false,
        user: optionOf(userOrfailure)
      );
    });
  }
}
